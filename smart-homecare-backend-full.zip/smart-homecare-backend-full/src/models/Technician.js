const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const TechnicianSchema = new Schema({
  name: String,
  phone: String,
  email: String,
  passwordHash: String,
  services: [String],
  isAvailable: { type: Boolean, default: true },
  fcmToken: String,
  createdAt: { type: Date, default: Date.now }
});
module.exports = mongoose.model('Technician', TechnicianSchema);
