const User = require('../models/User');
const jwt = require('jsonwebtoken');
const secret = process.env.JWT_SECRET || 'shh';
exports.sendOtp = async (req, res) => {
  const { phone } = req.body;
  if (!phone) return res.status(400).json({ error: 'Phone required' });
  const otp = Math.floor(1000 + Math.random()*9000).toString();
  console.log('Mock OTP for', phone, otp);
  let user = await User.findOne({ phone });
  if (!user) user = await User.create({ phone });
  return res.json({ ok: true, otp });
};
exports.verifyOtp = async (req, res) => {
  const { phone, otp } = req.body;
  if (!phone || !otp) return res.status(400).json({ error: 'Phone+OTP required' });
  let user = await User.findOne({ phone });
  if (!user) user = await User.create({ phone });
  const token = jwt.sign({ id: user._id, phone }, secret, { expiresIn: '30d' });
  res.json({ ok: true, token, user });
};
