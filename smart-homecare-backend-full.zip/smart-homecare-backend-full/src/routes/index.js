const express = require('express');
const router = express.Router();
const auth = require('../utils/auth');
const authCtrl = require('../controllers/authController');
const svcCtrl = require('../controllers/serviceController');
const bookCtrl = require('../controllers/bookingController');
const techCtrl = require('../controllers/techController');
const payCtrl = require('../controllers/paymentController');

// Auth
router.post('/auth/send-otp', authCtrl.sendOtp);
router.post('/auth/verify-otp', authCtrl.verifyOtp);

// Services
router.get('/services', svcCtrl.list);
router.post('/services', auth, svcCtrl.create);
router.put('/services/:id', auth, svcCtrl.update);
router.delete('/services/:id', auth, svcCtrl.remove);

// Bookings
router.post('/bookings', auth, bookCtrl.create);
router.get('/bookings', auth, bookCtrl.list);
router.get('/bookings/:id', auth, bookCtrl.detail);
router.put('/bookings/:id/assign', auth, bookCtrl.assign);
router.put('/bookings/:id/status', auth, bookCtrl.status);

// Technician
router.post('/admin/register-tech', techCtrl.register);
router.post('/admin/login', techCtrl.login);
router.get('/tech/:id/jobs', auth, techCtrl.jobsFor);
router.put('/tech/:id/status', auth, techCtrl.setAvailability);

// Payments
router.post('/payments/order', auth, payCtrl.createOrder);
router.post('/payments/verify', auth, payCtrl.verify);

// Seed
router.post('/seed', async (req, res)=> {
  const Service = require('../models/Service');
  await Service.deleteMany({});
  const list = [
    { title: 'Plumber', basePrice: 299, packages: [{name:'Basic',price:299},{name:'Standard',price:799},{name:'Premium',price:1499}] },
    { title: 'Electrician', basePrice: 199, packages: [{name:'Basic',price:199},{name:'Standard',price:599},{name:'Premium',price:999}] },
    { title: 'CCTV Technician', basePrice: 499, packages: [{name:'Basic',price:499},{name:'Standard',price:1299}] },
    { title: 'AC Repair', basePrice: 599, packages: [{name:'Basic',price:599},{name:'Standard',price:1499}] }
  ];
  for (const s of list) await Service.create({ title: s.title, slug: s.title.toLowerCase().replace(/\s+/g,'-'), basePrice: s.basePrice, packages: s.packages });
  res.json({ ok:true });
});

module.exports = router;
