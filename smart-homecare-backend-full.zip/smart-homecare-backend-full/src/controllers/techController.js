const Technician = require('../models/Technician');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const secret = process.env.JWT_SECRET || 'shh';
exports.register = async (req, res) => {
  const { name, phone, email, password, services } = req.body;
  const hash = await bcrypt.hash(password||'123456', 10);
  const t = await Technician.create({ name, phone, email, passwordHash: hash, services });
  res.json({ ok:true, tech: t });
};
exports.login = async (req, res) => {
  const { email, password } = req.body;
  const t = await Technician.findOne({ email });
  if (!t) return res.status(400).json({ error: 'No tech' });
  const match = await bcrypt.compare(password, t.passwordHash);
  if (!match) return res.status(401).json({ error: 'Invalid' });
  const token = jwt.sign({ id: t._id, role: 'technician' }, secret, { expiresIn: '30d' });
  res.json({ ok:true, token, tech: t });
};
exports.jobsFor = async (req, res) => {
  const Booking = require('../models/Booking');
  const jobs = await Booking.find({ technicianId: req.params.id }).populate('serviceId').populate('userId');
  res.json({ ok:true, jobs });
};
exports.setAvailability = async (req, res) => {
  const { isAvailable } = req.body;
  const t = await Technician.findByIdAndUpdate(req.params.id, { isAvailable }, { new: true });
  res.json({ ok:true, tech: t });
};
