const jwt = require('jsonwebtoken');
const secret = process.env.JWT_SECRET || 'shh';
module.exports = function(req, res, next) {
  const h = req.headers.authorization;
  if (!h) return res.status(401).json({ error: 'Missing auth' });
  const token = h.replace('Bearer ', '');
  try {
    const d = jwt.verify(token, secret);
    req.user = d;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Invalid token' });
  }
};
