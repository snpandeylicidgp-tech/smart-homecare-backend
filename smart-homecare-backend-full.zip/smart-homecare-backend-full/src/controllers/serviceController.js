const Service = require('../models/Service');
exports.list = async (req, res) => {
  const services = await Service.find();
  res.json({ ok: true, services });
};
exports.create = async (req, res) => {
  const { title, basePrice, packages } = req.body;
  const slug = title.toLowerCase().replace(/[^a-z0-9]+/g,'-');
  const s = await Service.create({ title, slug, basePrice, packages });
  res.json({ ok: true, service: s });
};
exports.update = async (req, res) => {
  const s = await Service.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json({ ok: true, service: s });
};
exports.remove = async (req, res) => {
  await Service.findByIdAndDelete(req.params.id);
  res.json({ ok: true });
};
