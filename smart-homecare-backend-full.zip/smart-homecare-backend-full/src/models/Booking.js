const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const BookingSchema = new Schema({
  userId: { type: Schema.Types.ObjectId, ref: 'User' },
  serviceId: { type: Schema.Types.ObjectId, ref: 'Service' },
  technicianId: { type: Schema.Types.ObjectId, ref: 'Technician', default: null },
  address: String,
  date: Date,
  timeSlot: String,
  package: String,
  price: Number,
  payment: { paid: { type: Boolean, default: false }, method: String, razorpay: {} },
  status: { type: String, enum: ['requested','assigned','on_way','arrived','in_progress','completed','cancelled'], default: 'requested' },
  createdAt: { type: Date, default: Date.now }
});
module.exports = mongoose.model('Booking', BookingSchema);
