const Razorpay = require('razorpay');
const crypto = require('crypto');
const Booking = require('../models/Booking');
const instance = new Razorpay({ key_id: process.env.RZP_KEY_ID||'', key_secret: process.env.RZP_KEY_SECRET||'' });
exports.createOrder = async (req, res) => {
  const { amount, receipt } = req.body;
  try {
    const order = await instance.orders.create({ amount, currency: 'INR', receipt });
    res.json({ ok:true, order });
  } catch (e) { res.status(500).json({ error: e.message }); }
};
exports.verify = async (req, res) => {
  const { razorpay_payment_id, razorpay_order_id, razorpay_signature, bookingId } = req.body;
  const shasum = crypto.createHmac('sha256', process.env.RZP_KEY_SECRET||'');
  shasum.update(razorpay_order_id + '|' + razorpay_payment_id);
  const expected = shasum.digest('hex');
  if (expected === razorpay_signature) {
    if (bookingId) await Booking.findByIdAndUpdate(bookingId, { 'payment.paid': true, 'payment.razorpay': { razorpay_payment_id, razorpay_order_id, razorpay_signature } });
    return res.json({ ok:true });
  } else return res.status(400).json({ error: 'Invalid signature' });
};
