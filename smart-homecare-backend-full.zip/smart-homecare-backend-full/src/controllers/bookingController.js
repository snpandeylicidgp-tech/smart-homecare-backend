const Booking = require('../models/Booking');
exports.create = async (req, res) => {
  const { serviceId, address, date, timeSlot, package: pkg, price } = req.body;
  const booking = await Booking.create({ userId: req.user.id, serviceId, address, date, timeSlot, package: pkg, price });
  res.json({ ok: true, booking });
};
exports.list = async (req, res) => {
  const q = {};
  if (req.query.status) q.status = req.query.status;
  const bookings = await Booking.find(q).populate('serviceId').populate('userId').populate('technicianId');
  res.json({ ok: true, bookings });
};
exports.detail = async (req, res) => {
  const b = await Booking.findById(req.params.id).populate('serviceId').populate('userId').populate('technicianId');
  res.json({ ok: true, booking: b });
};
exports.assign = async (req, res) => {
  const { technicianId } = req.body;
  const b = await Booking.findByIdAndUpdate(req.params.id, { technicianId, status: 'assigned' }, { new: true });
  res.json({ ok: true, booking: b });
};
exports.status = async (req, res) => {
  const { status } = req.body;
  const b = await Booking.findByIdAndUpdate(req.params.id, { status }, { new: true });
  res.json({ ok: true, booking: b });
};
